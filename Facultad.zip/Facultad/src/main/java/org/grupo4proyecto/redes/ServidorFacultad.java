package org.grupo4proyecto.redes;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.grupo4proyecto.entidades.Solicitud;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

public class ServidorFacultad implements Runnable {
    private final int puerto;
    private final ObjectMapper mapper = new ObjectMapper();

    public ServidorFacultad(int puerto) {
        this.puerto = puerto;
    }

    @Override
    public void run() {
        try (ZContext context = new ZContext()) {
            ZMQ.Socket socket = context.createSocket(SocketType.REP);
            socket.bind("tcp://*:" + puerto);
            System.out.println("[FACULTAD] Servidor esperando solicitudes de programas en puerto " + puerto);

            while (!Thread.currentThread().isInterrupted()) {
                String mensaje = socket.recvStr();
                System.out.println("[FACULTAD] Solicitud recibida: " + mensaje);

                // Decodificar solicitud
                Solicitud solicitud = mapper.readValue(mensaje, Solicitud.class);

                // Aquí podrías hacer lógica de validación o simulación

                String respuesta = "[FACULTAD] Solicitud del programa '" + solicitud.getPrograma() + "' recibida correctamente";
                socket.send(respuesta);
                System.out.println("[FACULTAD] Respuesta enviada a programa: " + respuesta);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
